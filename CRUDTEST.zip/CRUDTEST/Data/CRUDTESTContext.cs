﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using CRUDTEST.Models;

namespace CRUDTEST.Data
{
    public class CRUDTESTContext : DbContext
    {
        public CRUDTESTContext (DbContextOptions<CRUDTESTContext> options)
            : base(options)
        {
        }

        public DbSet<CRUDTEST.Models.Estudiantes> Estudiantes { get; set; }
    }
}
