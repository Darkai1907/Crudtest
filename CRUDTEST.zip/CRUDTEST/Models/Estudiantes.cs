﻿namespace CRUDTEST.Models
{
    public class Estudiantes
    {

        public int ID {get; set;}
        public string Nombre { get; set; }
        public string Genero { get; set; }
        public string Clase { get; set; }
        public string Direccion { get; set; }
        public string Nota { get; set; }



    }
}
