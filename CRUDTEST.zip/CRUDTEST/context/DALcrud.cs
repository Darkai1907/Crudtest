﻿using CRUDTEST.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;




namespace CRUDTEST.context
{
    public class DALcrud
    {
        readonly string connectionstring = "Data Source =  LAPTOP-KMVA8M2L; Initial Catalog= DALcrud;  Integrated Security=SSPI; User ID= sa; Password = 123456789; ";
        
        /// <summary>
        /// Este metodo ayuda a encontrar la lista de estudiantes 
        /// </summary>
        /// <returns></returns>
        
        public IEnumerable<Estudiantes> GetAllEstudiantes()
        {
            var EstudiantesList = new List<Estudiantes>();
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_GetAllEstudiantes", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    var Estudiantes = new Estudiantes
                    {
                        ID = Convert.ToInt32(dr["ID"].ToString()),
                        Nombre = dr["Nombre"].ToString(),
                        Genero = dr["Genero"].ToString(),
                        Clase = dr["Clase"].ToString(),
                        Direccion = dr["Direccion"].ToString(),
                        Nota = dr["Nota"].ToString()
                    };

                    EstudiantesList.Add(Estudiantes);

                }
                con.Close();
            }

            return EstudiantesList; 
 
        }

        /// <summary>
        /// crear nuevos estudiantes 
        /// </summary>
        /// <param name="estudiantes"></param>

        public void CreateEstudiantes (Estudiantes estudiantes)

        {
            using (SqlConnection con = new SqlConnection(connectionstring ))
            {
                SqlCommand cmd = new SqlCommand("SP_CreateNewEstudiantes", con)
                {
                    CommandType = CommandType.StoredProcedure
                };
                cmd.Parameters.AddWithValue("@Nombre", estudiantes.Nombre);
                cmd.Parameters.AddWithValue("@Genero", estudiantes.Genero);
                cmd.Parameters.AddWithValue("@Clase", estudiantes.Clase);
                cmd.Parameters.AddWithValue("@Direccion", estudiantes.Direccion);
                cmd.Parameters.AddWithValue("@Nota", estudiantes.Nota);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();



            }


        }

        /// <summary>
        /// Editar estudiantes 
        /// </summary>
        /// <param name="estudiantes"></param>

        public void UpdateEstudiantes(Estudiantes estudiantes)

        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_UpdateEstudiantes", con)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@ID", estudiantes.ID);
                cmd.Parameters.AddWithValue("@Nombre", estudiantes.Nombre);
                cmd.Parameters.AddWithValue("@Genero", estudiantes.Genero);
                cmd.Parameters.AddWithValue("@Clase", estudiantes.Clase);
                cmd.Parameters.AddWithValue("@Direccion", estudiantes.Direccion);
                cmd.Parameters.AddWithValue("@Nota", estudiantes.Nota);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();



            }


        }
        /// <summary>
        /// Borrar estudiantes 
        /// </summary>
        /// <param name="estudiantes"></param>

        public void DeleteEstudiantes(int ? ID)

        {
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_DeleteEstudiantes", con)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@ID",   ID);
                
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }
        /// <summary>
        /// encontrar estudiante por el ID 
        /// </summary>
        /// <param name="estudiantes"></param>

        public Estudiantes GetEstudianteByID(int? ID)

        {
            var Estudiantes = new Estudiantes(); 
            using (SqlConnection con = new SqlConnection(connectionstring))
            {
                SqlCommand cmd = new SqlCommand("SP_GetEstudiantesByID", con)
                {
                    CommandType = CommandType.StoredProcedure
                };

                cmd.Parameters.AddWithValue("@ID", ID);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    Estudiantes.ID = Convert.ToInt32(dr["ID"].ToString());
                    Estudiantes.Nombre = dr["Nombre"].ToString();
                    Estudiantes.Genero = dr["Genero"].ToString();
                    Estudiantes.Clase = dr["Clase"].ToString();
                    Estudiantes.Direccion = dr["Direccion"].ToString();
                    Estudiantes.Nota = dr["Nota"].ToString();
                }
                con.Close();

            }
            return Estudiantes; 


        }

    }
}
